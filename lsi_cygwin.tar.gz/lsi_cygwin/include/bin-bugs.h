#ifndef REPORT_BUGS_TO
#define REPORT_BUGS_TO	"<URL:http://www.sourceware.org/bugzilla/>"
#endif
